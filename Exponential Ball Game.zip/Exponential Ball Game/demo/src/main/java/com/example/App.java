package com.example;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.ArrayList;

public class App extends Application {

    private static int WIDTH = 650;
    private static int HEIGHT = 650;
    private static int BALL_RADIUS = 20;
    private static double BALL_SPEED = 10;
    private static int ball_count = 0;

    private static Color[] colours = { Color.PURPLE, Color.BLUE, Color.TURQUOISE, Color.GREEN, Color.YELLOW,
            Color.ORANGE, Color.RED };
    private static int colour_select = 0;
    private boolean ballMovementsCalculated = false;
    private ArrayList<BouncingBall> balls;
    private ArrayList<BouncingBall> newBalls;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Bouncing Ball App");

        Pane root = new Pane();
        Scene scene = new Scene(root, WIDTH, HEIGHT, Color.BLACK);
        // Create an array of bouncing balls
        balls = new ArrayList<>();
        newBalls = new ArrayList<>();

        BouncingBall first_ball = new BouncingBall();
        balls.add(first_ball);
        root.getChildren().add(first_ball.getBall());

        // Create a timeline for ball movement
        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(16), event -> {
            if (ballMovementsCalculated) {
                // Update existing balls
                for (BouncingBall ball : balls) {
                    double ballX = ball.getBall().getCenterX() + ball.getDirectionX() * BALL_SPEED;
                    double ballY = ball.getBall().getCenterY() + ball.getDirectionY() * BALL_SPEED;

                    // Bounce off the walls
                    if (ballX - BALL_RADIUS <= 0 || ballX + BALL_RADIUS >= WIDTH) {
                        ball.setDirectionX(ball.getDirectionX() * -1);

                        if (colour_select == 6) {
                            colour_select = 0;
                        } else {
                            colour_select++;
                        }

                        BouncingBall additional_ball = new BouncingBall();
                        this.ball_count ++;
                        System.out.println(this.ball_count);
                        newBalls.add(additional_ball);
                    }

                    if (ballY - BALL_RADIUS <= 0 || ballY + BALL_RADIUS >= HEIGHT) {
                        ball.setDirectionY(ball.getDirectionY() * -1);
                    }
                    

                    // Update ball position
                    ball.getBall().setCenterX(ballX);
                    ball.getBall().setCenterY(ballY);
                }

                // Add new balls to the main list and scene
                for (BouncingBall newBall : newBalls) {
                    balls.add(newBall);
                    root.getChildren().add(newBall.getBall());
                }
                newBalls.clear();

                // Reset the flag after updating ball positions
                ballMovementsCalculated = false;
            } else {
                // Set the flag to true to indicate that ball movements need to be calculated
                ballMovementsCalculated = true;
            }
        }));

        // Set the cycle count to indefinite for continuous animation
        timeline.setCycleCount(Timeline.INDEFINITE);

        // Start the timeline
        timeline.play();

        primaryStage.setScene(scene);
        primaryStage.show();
    }


    private static class BouncingBall {
        private Circle ball;
        private double directionX;
        private double directionY;

        public BouncingBall() {
            this.ball = new Circle(BALL_RADIUS, colours[colour_select]);
            // Generate a random angle in radians within a 360-degree range
            double angle = Math.random() * 2 * Math.PI;

            // Calculate the X and Y components of the direction vector
            this.directionX = Math.cos(angle);
            this.directionY = Math.sin(angle);
            // Set initial position of the ball
            this.ball.setCenterX(WIDTH / 2);
            this.ball.setCenterY(HEIGHT / 2);
        }

        public Circle getBall() {
            return ball;
        }

        public double getDirectionX() {
            return directionX;
        }

        public double getDirectionY() {
            return directionY;
        }

        public void setDirectionX(double directionX) {
            this.directionX = directionX;
        }

        public void setDirectionY(double directionY) {
            this.directionY = directionY;
        }
    }
}
